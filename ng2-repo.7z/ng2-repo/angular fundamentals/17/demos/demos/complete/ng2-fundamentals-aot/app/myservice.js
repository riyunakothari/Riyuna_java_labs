"use strict";
var core_1 = require('@angular/core');
exports.MY_TOKEN = new core_1.OpaqueToken('mine');
//# sourceMappingURL=myservice.js.map