import { OpaqueToken } from '@angular/core'

export let JQ_TOKEN = new OpaqueToken('jQuery');