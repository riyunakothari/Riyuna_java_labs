"use strict";
var platform_browser_1 = require('@angular/platform-browser');
var app_module_ngfactory_1 = require('../aot/app/app.module.ngfactory');
platform_browser_1.platformBrowser().bootstrapModuleFactory(app_module_ngfactory_1.AppModuleNgFactory);
//# sourceMappingURL=somefile.js.map