"use strict";
exports.environment = {
    production: true
};
//# sourceMappingURL=environment.prod.js.map