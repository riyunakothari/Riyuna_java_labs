export {EventService} from './event.service'
export {IEvent, ISession} from './event.model'
export {restrictedWords} from './restricted-words.validator'
export {DurationPipe} from './duration.pipe'